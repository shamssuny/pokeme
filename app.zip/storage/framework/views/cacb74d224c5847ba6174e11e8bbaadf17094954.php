<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
            <input class="form-control" id="foo" type="text" value="<?php echo e($_SERVER['SERVER_NAME']); ?>/profile/<?php echo e($uid); ?>">
            <button class="cop btn btn-success" data-clipboard-action="copy" data-clipboard-target="#foo">Copy Your Profile Url To Recive Message!</button>
                <div class="panel-heading">Message board</div>
                

                <div class="panel-body text-center">
                    <?php $__empty_1 = true; foreach($msg as $m): $__empty_1 = false; ?>
                        <div class="mess">
                            <?php echo e($m->content); ?>

                            <form action="/home" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                                <input type="hidden" name="pid" value="<?php echo e($m->id); ?>">
                                <input class="btn btn-danger" type="submit" value="Delete">
                                
                            </form>
                        </div>
                        <hr>
                    <?php endforeach; if ($__empty_1): ?>
                        No Message Available.
                    <?php endif; ?>
                    <?php echo e($msg->links()); ?>

                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>